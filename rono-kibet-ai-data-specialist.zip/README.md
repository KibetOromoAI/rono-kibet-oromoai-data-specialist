# Rono Kibet – AI Data Specialist

## Professional Summary
AI Data Specialist experienced in data annotation, AI evaluation, language quality assurance, data collection, and dataset validation.

## Skills
- AI Data Annotation
- Data Labeling & Classification
- AI Response Evaluation
- Quality Assurance
- Oromo Language Review
- Data Collection & Validation
- Google Sheets & Excel
- Digital Research

## Contact
Email: malebobolema@gmail.com
LinkedIn: www.linkedin.com/in/rono-kibet-oromoAI
